
Data on perception of security from Mexico's 2020 National Survey of Crime, Victimization and Public Security Perceptions (Encuesta Nacional de Victimización y Percepción sobre Seguridad Pública, ENVIPE), from the National Institute of Geography and Statistics (Instituto Nacional de Geografía y Estadística, INEGI) available at <https://www.inegi.org.mx/contenidos/programas/envipe/2020/datosabiertos/conjunto_de_datos_envipe2020_csv.zip>

For easy access to the data here we include the specific set that was used in the project.

If downloaded directly from the INEGI link <https://www.inegi.org.mx/contenidos/programas/envipe/2020/datosabiertos/conjunto_de_datos_envipe2020_csv.zip>, the path to the specific data set once the full file is downloaded should be: conjunto_de_datos_envipe2020_csv/conjunto_de_datos_TPer_Vic1_ENVIPE_2020/conjunto_de_datos/conjunto_de_datos_TPer_Vic1_ENVIPE_2020.csv

